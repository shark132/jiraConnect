# coding: utf-8

MULTICASE_URL = "http://localhost:9999/api/multicase"